export const clientId  = "604220926946-1oqbrr18me54a3icgo5b4opu4c857pu5.apps.googleusercontent.com";
// export const clientId  = "1005832961076-8r42t9ftllgea2fphurkho2bsq335noc.apps.googleusercontent.com";

export const linkedInClientId = "78ybgh06jnivad";

export const linkedInRedirectURL = "http://localhost:3000/login";

export const linkedInClientSecret = "PaU2T7EJiEIi1raZ";
