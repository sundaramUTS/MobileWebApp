export default class UTSRoutes {
	static HOMEROUTE = '/';
	static LOGINROUTE = '/login';	
}